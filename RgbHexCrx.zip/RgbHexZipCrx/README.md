# RGB and HEX Converter

This is the first chrome extension that I have ever programed.

It's for the conversion between rgb and hex, it's fast and stable. Enjoy it.

点击crx文件安装，如果安装失败的话，开始chrome扩展的开发者模式即可。

本来想发布到chrome web store的，但是需要使用google wallet支付5美元的入场费，在大天朝开google wallet太蛋疼了。。